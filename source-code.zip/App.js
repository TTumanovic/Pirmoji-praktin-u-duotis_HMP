import React, { useState } from "react";
import ButtonPanel from "./ButtonPanel.js";
import TextPanel from "./TextPanel";
import "./styles.css";

const textsInitial = [
  { id: 1, label: "Text1", color: "black" },
  { id: 2, label: "Text2", color: "black" },
  { id: 3, label: "Text3", color: "black" },
  { id: 4, label: "Text4", color: "black" },
];

export default function App() {
  const [texts, setTexts] = useState(textsInitial);

  const toggleColor = (id) => {
    setTexts((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, color: t.color === "black" ? "red" : "black" }
          : t
      )
    );
  };

  return (
    <div className="container">
      <ButtonPanel onButtonClick={toggleColor} />
      <TextPanel texts={texts} />
    </div>
  );
}
