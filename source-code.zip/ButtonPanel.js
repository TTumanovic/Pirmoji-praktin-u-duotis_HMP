import React from "react";

export default function ButtonPanel({ onButtonClick }) {
  return (
    <div className="buttons">
      <button onClick={() => onButtonClick(1)}>Button1</button>
      <button onClick={() => onButtonClick(2)}>Button2</button>
      <button onClick={() => onButtonClick(3)}>Button3</button>
      <button onClick={() => onButtonClick(4)}>Button4</button>
    </div>
  );
}
