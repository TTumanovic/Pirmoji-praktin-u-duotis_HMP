import React from "react";

export default function TextPanel({ texts }) {
  return (
    <div className="texts">
      {texts.map((t) => (
        <p key={t.id} style={{ color: t.color }}>
          {t.label}
        </p>
      ))}
    </div>
  );
}
